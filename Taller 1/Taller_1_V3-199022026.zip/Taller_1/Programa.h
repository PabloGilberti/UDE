#ifndef PROGRAMA_H_INCLUDED
#define PROGRAMA_H_INCLUDED
#include "Arbol.h"
#include "ListaExpresiones.h"
#include "ListaString.h"
String valor;

printf("Ingrese una expresion");

scanf("%f",&valor)

if (listavacia(ListaExpresiones l)){;
    crearLista(ListaExpresiones l);
}else{

    printf("Error la lista de expresiones no esta vacia");
}


#endif // PROGRAMA_H_INCLUDED
