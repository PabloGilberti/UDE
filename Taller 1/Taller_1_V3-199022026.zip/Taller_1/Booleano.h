#ifndef BOOLEANO_H_INCLUDED
#define BOOLEANO_H_INCLUDED
#include <stdio.h>
typedef enum{FALSE,TRUE}Boolean;


//Carga el boolreano
 void cargar (Boolean & b);

 /* muestra en pantalla el valor de la variable */
 void mostrar (Boolean b);

#endif // BOOLEANO_H_INCLUDED
