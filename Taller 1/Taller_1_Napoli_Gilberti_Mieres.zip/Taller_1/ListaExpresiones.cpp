#include <cstdio>
#include "ListaExpresiones.h"
#include "Expresion.h"
#include "Arbol.h"

// Crear lista vac�a
void crearLista(ListaExpresiones &l)
{
    l = NULL;
}

// Devuelve TRUE si est� vac�a
Boolean listavacia(ListaExpresiones l)
{
    return (l == NULL) ? TRUE : FALSE;
}

// Pr�ximo �ndice correlativo
int obtenerProximoIndice(ListaExpresiones l)
{
    if (l == NULL)
        return 1;

    nodoL* aux = l;
    while (aux->sig != NULL)
        aux = aux->sig;

    return aux->info.indice + 1;
}

// Insertar nueva expresi�n (copia el �rbol)
void insertarExpresion(ListaExpresiones &l, Arbol a)
{
    nodoL* nuevo = new nodoL;

    int idx = obtenerProximoIndice(l);

    // Crear expresi�n usando tu constructor
    nuevo->info = EXP_Crear(idx, a);

    nuevo->sig = NULL;

    if (l == NULL)
    {
        l = nuevo;
    }
    else
    {
        nodoL* aux = l;
        while (aux->sig != NULL)
            aux = aux->sig;
        aux->sig = nuevo;
    }
}

// Verifica existencia de �ndice
Boolean existeIndice(ListaExpresiones l, int indice)
{
    nodoL* aux = l;
    while (aux != NULL)
    {
        if (aux->info.indice == indice)
            return TRUE;
        aux = aux->sig;
    }
    return FALSE;
}

// Obtiene el �rbol guardado
Arbol obtenerExpresion(ListaExpresiones l, int indice)
{
    nodoL* aux = l;
    while (aux != NULL)
    {
        if (aux->info.indice == indice)
            return aux->info.terminos;

        aux = aux->sig;
    }
    return NULL;
}

// Mostrar todas las expresiones
void mostrarExpresiones(ListaExpresiones l)
{
    nodoL* aux = l;

    while (aux != NULL)
    {
        EXP_Mostrar(aux->info);
        aux = aux->sig;
    }
}

// Liberar lista completa
void liberarLista(ListaExpresiones &l)
{
    nodoL* aux = l;

    while (aux != NULL)
    {
        nodoL* borrar = aux;
        aux = aux->sig;

        EXP_Liberar(borrar->info);
        delete borrar;
    }

    l = NULL;
}
