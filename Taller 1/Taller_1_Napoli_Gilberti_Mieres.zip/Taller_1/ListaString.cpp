#include "ListaString.h"



void   LS_Crear(ListaString &L){


            L = NULL;

};

Boolean   LS_EsVacia(ListaString L){

            Boolean es = FALSE;

            if (L == NULL)
                es = TRUE;

            return es;

};

int    LS_Cantidad(ListaString L){

        int contador=0;
        NodoS * aux = L;
        while(aux!=NULL){

            contador ++;
            aux=aux->sig;

        }
        return contador;
};

//leer lo ue viene en la posicion
String LS_EnPos(ListaString L, int pos)
{
    if (pos <= 0)
        return NULL;

    int cant = LS_Cantidad(L);
    if (pos > cant)
        return NULL;

    int i = 1;
    NodoS* aux = L;

    while (aux != NULL && i < pos)
    {
        aux = aux->sig;
        i++;
    }

    if (aux == NULL)
        return NULL;

    return aux->palabra;
}

void   LS_AgregarFinal(ListaString &L, String s){ // copia din�mica
 // Crear nodo nuevo
    NodoS * nuevo = new NodoS;

    // Reservar memoria para el string
    strcrear(nuevo->palabra);

/*
    strlar(s) devuelve el largo de la cadena (sin contar '\0').

    + 1 reserva espacio para el '\0' final.

    new char[...] crea un array din�mico de caracteres.

    nuevo->palabra ahora apunta a un bloque de memoria propio donde se guardar� la copia.

*/
    strcop(nuevo->palabra, s);
    //Copia el texto al nuevo nodo

    nuevo->sig = NULL;

    if (L == NULL)
    {
        L = nuevo;
    }
    else
    {
        NodoS* aux = L;
        while (aux->sig != NULL)
        {
            aux = aux->sig;
        }
        aux->sig = nuevo;
    }

}

void LS_Split(String linea, ListaString &L){//Cortar el string
    // Inicializar lista vac�a
    L = NULL;

    int i = 0; //indice qu voy recorriendo
    int largo = strlar(linea);//cantidad de carcteres

    while (i < largo)
    {
        // 1) Saltear espacios
        //Ejemplo si ten�s " simple 5":
        //avanza i hasta la primera letra de simple.
        while (i < largo && linea[i] == ' ')
        {
            i++;
        }

        //Si llego al final, corto
        if (i >= largo)
            break;

        //Empezar a armar la palabra
        //Guardo el indice donde comienza la palabra
        int inicio = i;

        //Voy a ir avanzando mientras sea una palabra (NO ESPACIOS)
        while (i < largo && linea[i] != ' ')
        {
            i++;
        }

        int fin = i;

        //Calcular tama�o palabra
        //Si la Palabra es "compuesta" inicio apunta a la C y Fin a la ultima letra (seria 9)
        int tamano = fin - inicio;

        //Crear un especie de  buffer temporal para copiar el split
        String palabra = new char[tamano + 1];
        //copia caracter por caracter
        for (int j = 0; j < tamano; j++)
        {
            palabra[j] = linea[inicio + j];
        }
        //finaliza el string
        palabra[tamano] = '\0';

        //Agregar a la lista
        LS_AgregarFinal(L, palabra);

        //Liberar buffer temporal
        delete[] palabra;
    }
}

void   LS_Liberar(ListaString &L)
{

    //No podemos mover directamente L porque perder�amos referencia.
    NodoS * aux = L;

        //voy a recorre toda la lista mintra tenga nodos
    while (aux != NULL)
    {
        NodoS * borrar = aux;   // guardo nodo actual
        aux = aux->sig;        // avanzo antes de borrar

        delete[] borrar->palabra;  // liberar string
        delete borrar;             // liberar nodo
    }

    L = NULL;  // dejar lista vac�a
}
