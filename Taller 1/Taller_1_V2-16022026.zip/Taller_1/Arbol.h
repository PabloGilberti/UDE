#ifndef ARBOL_H_INCLUDED
#define ARBOL_H_INCLUDED
#include "Termino.h"

typedef struct NodoArb{ Termino info;
                        int numeroNodo;
                        NodoArb * hizq;
                        NodoArb * hder;
                        }nodoA;

 typedef nodoA * Arbol;

// Retorna �rbol vac�o (NULL)
Arbol ARB_CrearVacio();

// Devuelve true si a == NULL
Boolean  ARB_EsVacio(Arbol a);

// Crea un nodo con "info" y sus hijos (reserva memoria)
Arbol ARB_CrearNodo(Termino info, Arbol izq, Arbol der);


/* ============================
   Gesti�n de memoria
   ============================ */

// Copia profunda del �rbol (se usa en comando compuesta)
Arbol ARB_Copiar(Arbol a);

// Libera todo el �rbol (postorden) y deja a = NULL
void  ARB_Liberar(Arbol& a);


/* ============================
   Mostrar (impresi�n)
   ============================ */

// Imprime el �rbol como expresi�n (con par�ntesis para reflejar estructura)
// Ej: ( (12 - x) * x )
void  ARB_Mostrar(Arbol a);


/* ============================
   Evaluaci�n (calcular)
   ============================ */

// Eval�a el �rbol con un valor para x.
// Devuelve OK o error (por ejemplo divisi�n entre 0).
TipoError ARB_Evaluar(Arbol a, int valorX, int& resultado);


/* ============================
   Comparaci�n (iguales)
   ============================ */

// Devuelve true si dos �rboles son sint�cticamente iguales:
// misma estructura y mismo contenido en cada nodo.
Boolean  ARB_Iguales(Arbol a, Arbol b);


/* ============================
   Persistencia (guardar / recuperar)
   ============================ */

// Guarda el �rbol en un archivo (serializaci�n).
// - Debe devolver ERR_ARCHIVO_EXISTE si ya existe (si esa es tu regla).
TipoError ARB_GuardarEnArchivo(Arbol a, const char* nombreArchivo);

// Carga un �rbol desde un archivo (deserializaci�n).
// - Debe devolver ERR_ARCHIVO_NO_EXISTE si no existe.
TipoError ARB_CargarDesdeArchivo(Arbol& a, const char* nombreArchivo);

//evaluar arbol(calcular expresion del arbol)puede  devolver un double float

//modulo archivo

//modulo de arbol evaluar un arbol devuelve float o double y lo que entra el punbtero al arbol o el indice llamara evaluar arbol, en lista de expresion necesito ingresar el numero entero del indice
//Deberes:

#endif // ARBOL_H_INCLUDED
