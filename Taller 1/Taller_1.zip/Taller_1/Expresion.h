#ifndef EXPRESION_H_INCLUDED
#define EXPRESION_H_INCLUDED
#include "Arbol.h"

typedef struct {int indice;
                Arbol terminos;
                }Expresion;


#endif // EXPRESION_H_INCLUDED
