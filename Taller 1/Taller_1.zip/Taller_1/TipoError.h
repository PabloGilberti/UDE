#ifndef TIPOERROR_H_INCLUDED
#define TIPOERROR_H_INCLUDED


typedef enum {
                ERROR_NINGUNO,               // No hay error
                ERROR_CARACTER_INVALIDO,     // S�mbolo desconocido
                ERROR_TERMINO_INVALIDO,      // Termino mal formado
                ERROR_PARENTESIS,            // Par�ntesis mal balanceados
                ERROR_OPERADOR,              // Operador inv�lido o mal ubicado
                ERROR_VARIABLE,              // Variable inv�lida
                ERROR_EXPRESION_INCOMPLETA   // Falta operando u operador
                } TipoError;

#endif // TIPOERROR_H_INCLUDED
