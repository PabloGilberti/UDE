#ifndef STRING_H_INCLUDED
#define STRING_H_INCLUDED
 const int MAX =80;
 typedef char  * String;



#endif // STRING_H_INCLUDED
