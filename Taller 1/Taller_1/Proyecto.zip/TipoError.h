#ifndef TIPOERROR_H_INCLUDED
#define TIPOERROR_H_INCLUDED
#include "String.h"

typedef enum{
    OK = 0,

    // Errores generales de par�metros / sintaxis
    ERR_CANT_PARAM,     // faltan o sobran par�metros
    ERR_PARAMETRO,      // par�metro con formato inv�lido (ej: simple no recibe x/entero)

    // �ndices
    ERR_INDICE_FORMATO, // �ndice no es entero positivo
    ERR_INDICE_NOEXISTE,// �ndice v�lido pero no existe en memoria

    // Operadores
    ERR_OPERADOR,       // operador no es + - * /

    // Estado de memoria
    ERR_MEMORIA_VACIA,  // no hay expresiones cargadas

    // Archivos
    ERR_NOMBRE_ARCHIVO, // archivo no es puramente alfab�tico
    ERR_ARCHIVO_EXISTE, // ya existe archivo.txt (en guardar)
    ERR_ARCHIVO_NOEXISTE,// no existe archivo.txt (en recuperar)
    ERR_ARCHIVO_IO,     // error gen�rico de I/O (opcional)

    // C�lculo
    ERR_DIV_CERO        // divisi�n por cero durante evaluar

} TipoError;

// Para mostrar mensajes claros
void Error(TipoError e);

#endif
