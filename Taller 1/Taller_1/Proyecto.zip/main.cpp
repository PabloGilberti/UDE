#include <stdio.h>
#include "ListaString.h"
#include "String.h"

int main()
{
    ListaString L;
    LS_Crear(L);

    // 1️⃣ Probar Split
    String linea;
    strcrear(linea);

    printf("Linea original:\n");
    scan(linea);

    LS_Split(linea, L);

    // 2️⃣ Mostrar cantidad
    int cant = LS_Cantidad(L);
    printf("Cantidad de Parsing: %d\n", cant);

    // 3️⃣ Mostrar cada elemento
    for (int i = 0; i < cant; i++)   // IMPORTANTE: < cant (no <=)
    {
        String palabra = LS_EnPos(L, i);

        if (palabra != NULL)
        {
            printf("String %d: ", i);
            printf(palabra);   // usamos tu print del TAD String
            printf("\n");
        }
    }

    // 4️⃣ Liberar memoria
    LS_Liberar(L);

    if (L == NULL)
        printf("Lista liberada correctamente.\n");

    return 0;
}
