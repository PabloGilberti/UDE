#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include "Torneo.h"


void MenuPrincipal(int &opcion);
void MenuAltasBajas(int &opcion);
void MenuConsultas(int &opcion);
void MenuListados(int &opcion);

#endif // MENU_H_INCLUDED
