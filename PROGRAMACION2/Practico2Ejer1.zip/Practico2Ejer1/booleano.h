#ifndef BOOLEANO_H_INCLUDED
#define BOOLEANO_H_INCLUDED


typedef enum {FALSE,TRUE} booleano;

#endif // BOOLEANO_H_INCLUDED


