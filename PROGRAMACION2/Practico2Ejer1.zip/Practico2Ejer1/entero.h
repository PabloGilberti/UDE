#ifndef ENTERO_H_INCLUDED
#define ENTERO_H_INCLUDED

void suap(int &num1, int &num2);

#endif // ENTERO_H_INCLUDED
