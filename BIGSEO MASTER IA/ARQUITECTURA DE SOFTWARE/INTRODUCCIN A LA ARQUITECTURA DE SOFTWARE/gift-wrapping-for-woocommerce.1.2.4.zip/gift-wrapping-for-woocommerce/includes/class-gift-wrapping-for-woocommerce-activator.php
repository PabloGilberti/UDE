<?php

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0
 * @package    Tgpc_Wc_Gift_Wrap
 * @subpackage Tgpc_Wc_Gift_Wrap/includes
 */
class Tgpc_Wc_Gift_Wrap_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * @since    1.0
	 */
	public static function activate() {

	}

}
